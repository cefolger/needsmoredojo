define([
    './nestedpackage/ModuleC'
], function(ModuleC)  {

});