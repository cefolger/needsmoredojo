define([
    '../ModuleB'
], function(ModuleB)  {

});