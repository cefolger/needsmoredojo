define([

], function() {
    return declare(null, {

    });
});